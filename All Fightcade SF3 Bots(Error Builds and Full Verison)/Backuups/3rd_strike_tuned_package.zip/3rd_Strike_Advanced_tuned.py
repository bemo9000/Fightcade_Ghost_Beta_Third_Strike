#!/usr/bin/env python3
"""
3rd_Strike_Advanced_tuned.py

This script is an enhanced, CLI-first Fightcade/FBNeo 3rd Strike bot with:
- Gamepad calibration logger for Mayflash F300 (axes/buttons)
- Tuned special-move detection using joystick/button sequences
- Automatic ffmpeg short-clip capture on large health drops (KO detection)
- OCR calibration GUI (Tkinter) to set regions for character/SA reading
- GhostAI & Recorder integrated (expanded)
- Robust window detection and xdotool input sending

Usage:
  python3 3rd_Strike_Advanced_tuned.py

Dependencies (optional, for full features):
  sudo apt install xdotool tesseract-ocr ffmpeg python3-tk
  pip install pygame pynput mss opencv-python numpy pillow pytesseract

Configured for your environment (can be edited in script):
  FIGHTCADE_LOG_PATH = /home/bemo9000/.var/app/com.fightcade.Fightcade/data/config/fcadefbneo/presets/cps.ini
  CAPTURE_WIDTH = 640
  CAPTURE_HEIGHT = 480
  CAPTURE_FPS = 60
"""

import time, threading, subprocess, shutil, sys, os, math, json
from pathlib import Path
from collections import deque
from dataclasses import dataclass
from typing import Optional, List, Tuple, Dict

# Optional libraries
try:
    import pygame
    HAS_PYGAME = True
except Exception:
    HAS_PYGAME = False
try:
    from pynput import keyboard as kb
    HAS_PYNPUT = True
except Exception:
    HAS_PYNPUT = False
try:
    import mss, cv2, numpy as np
    HAS_VISION = True
except Exception:
    HAS_VISION = False
try:
    import pytesseract
    from PIL import Image
    HAS_OCR = True
except Exception:
    HAS_OCR = False
try:
    import tkinter as tk
    from tkinter import simpledialog, messagebox
    HAS_TK = True
except Exception:
    HAS_TK = False

XDOTOOL = shutil.which("xdotool") is not None
FFMPEG = shutil.which("ffmpeg") is not None

# User settings (edit if needed)
FIGHTCADE_LOG_PATH = "/home/bemo9000/.var/app/com.fightcade.Fightcade/data/config/fcadefbneo/presets/cps.ini"
CAPTURE_WIDTH = 640
CAPTURE_HEIGHT = 480
CAPTURE_FPS = 60
FFMPEG_CLIP_DURATION = 2  # seconds

CONFIG_SAVE = Path.home() / ".3rd_strike_tuned_cfg.json"
CAL_LOG = Path.home() / ".3rd_strike_calibration.json"

# ---------------- Data structures ----------------
@dataclass
class MatchInfo:
    p1_name: str = "Alex"
    p2_name: str = "Ryu"
    p1_sa: str = "SA1"
    p2_sa: str = "SA1"
    p1_health: float = 1.0
    p2_health: float = 1.0
    p1_super: float = 0.0
    p2_super: float = 0.0
    distance_px: int = 180
    last_action: str = ""
    last_result: str = ""
    timestamp: float = 0.0

# ---------------- Utilities ----------------
def find_best_game_window(fuzzy="Fightcade") -> Optional[str]:
    if not XDOTOOL:
        print("xdotool missing")
        return None
    try:
        r = subprocess.run(["xdotool","search","--name",fuzzy], capture_output=True, text=True)
        ids = [l.strip() for l in r.stdout.splitlines() if l.strip()]
        # prefer FBNeo/3rd Strike titles
        for wid in ids:
            try:
                name = subprocess.run(["xdotool","getwindowname",wid], capture_output=True, text=True).stdout.lower()
                if any(k in name for k in ("fbneo","3rd strike","street fighter")):
                    return wid
            except Exception:
                continue
        return ids[0] if ids else None
    except Exception as e:
        print("find window error:", e)
        return None

def activate_and_send(window_id: str, key: str) -> bool:
    if not XDOTOOL or not window_id:
        return False
    try:
        subprocess.run(["xdotool","windowactivate","--sync",window_id], check=True)
        proc = subprocess.run(["xdotool","key","--window",window_id,"--clearmodifiers",key], capture_output=True, text=True)
        # debug output
        if proc.returncode != 0:
            print("xdotool error:", proc.stderr.strip())
        return proc.returncode == 0
    except Exception as e:
        print("activate_and_send exception:", e)
        return False

# ---------------- Calibration logger for gamepad ----------------
def run_gamepad_calibration(duration: int = 10):
    """Logs axes and buttons values for `duration` seconds to CAL_LOG."""
    if not HAS_PYGAME:
        print("pygame not installed; cannot calibrate gamepad.")
        return
    pygame.init()
    pygame.joystick.init()
    count = pygame.joystick.get_count()
    if count == 0:
        print("No gamepads detected.")
        return
    j = pygame.joystick.Joystick(0)
    j.init()
    print(f"Calibrating gamepad: {j.get_name()} for {duration}s. Move stick and press buttons.")
    end = time.time() + duration
    records = []
    try:
        while time.time() < end:
            pygame.event.pump()
            axes = [j.get_axis(i) for i in range(j.get_numaxes())]
            buttons = [j.get_button(i) for i in range(j.get_numbuttons())]
            records.append({"t": time.time(), "axes": axes, "buttons": buttons})
            time.sleep(1.0/30.0)
    finally:
        j.quit()
    # reduce samples for storage
    trimmed = records[::max(1, len(records)//300)]
    try:
        CAL_LOG.write_text(json.dumps({"name": j.get_name(), "samples": trimmed}, indent=2))
        print("Calibration saved to", CAL_LOG)
    except Exception as e:
        print("Failed to save calibration:", e)

# ---------------- Special-move detection tuned for joystick ----------------
class JoystickInputReader:
    """Reads joystick axes/buttons and produces normalized directional states and button events."""
    def __init__(self, joystick_index=0, axis_deadzone=0.25):
        self.joystick_index = joystick_index
        self.axis_deadzone = axis_deadzone
        self.running = False
        self.thread = None
        self.callbacks = []  # functions to call with event ('axis', idx, val) or ('button', idx, val)
        if HAS_PYGAME:
            pygame.init()
            pygame.joystick.init()
            if pygame.joystick.get_count() == 0:
                print("No joysticks found for JoystickInputReader.")
            else:
                self.j = pygame.joystick.Joystick(joystick_index)
                self.j.init()
        else:
            self.j = None

    def start(self):
        if not HAS_PYGAME or not self.j:
            return
        self.running = True
        self.thread = threading.Thread(target=self._poll_loop, daemon=True)
        self.thread.start()

    def stop(self):
        self.running = False
        if self.thread:
            self.thread.join(timeout=1.0)

    def _poll_loop(self):
        while self.running:
            try:
                pygame.event.pump()
                axes = [self.j.get_axis(i) for i in range(self.j.get_numaxes())]
                buttons = [self.j.get_button(i) for i in range(self.j.get_numbuttons())]
                # produce directional events based on axes
                lx = axes[0] if len(axes) > 0 else 0.0
                ly = axes[1] if len(axes) > 1 else 0.0
                # normalize to directional strings
                dir_state = self._axes_to_direction(lx, ly)
                # call callbacks with direction and raw values
                for cb in self.callbacks:
                    cb(('dir', dir_state))
                    for i,a in enumerate(axes): cb(('axis', i, a))
                    for i,b in enumerate(buttons): cb(('button', i, b))
            except Exception:
                pass
            time.sleep(1.0/120.0)

    def _axes_to_direction(self, lx, ly):
        ax = 0 if abs(lx) < self.axis_deadzone else (-1 if lx < 0 else 1)
        ay = 0 if abs(ly) < self.axis_deadzone else (-1 if ly < 0 else 1)
        # map to directional names used in detector
        if ax == -1 and ay == 1: return "up-left"
        if ax == 1 and ay == 1: return "up-right"
        if ax == -1 and ay == -1: return "down-left"
        if ax == 1 and ay == -1: return "down-right"
        if ax == -1: return "left"
        if ax == 1: return "right"
        if ay == 1: return "up"
        if ay == -1: return "down"
        return "neutral"

# Sequence detector using joystick reader
class JoySeqDetector:
    def __init__(self, maxlen=128):
        self.buf = deque(maxlen=maxlen)  # (time, event_str)
    def push(self, ev):
        # ev is ('dir', 'left') or ('button', idx, val)
        if ev[0] == 'dir':
            self.buf.append((time.time(), ev[1]))
        elif ev[0] == 'button' and ev[2] == 1:
            self.buf.append((time.time(), f"b{ev[1]}"))
    def last_seq(self, n=8):
        return [e for t,e in list(self.buf)[-n:]]
    def detect_hadoken(self):
        seq = self.last_seq(8)
        s = " ".join(seq)
        # patterns: down down-right right + any punch button bX within 300ms
        for i in range(len(seq)-3):
            if seq[i] == "down" and ("down-right" in seq[i+1] or "down-right" == seq[i+1]) and ("right" in seq[i+2] or seq[i+2]=="right"):
                # look ahead for button press
                for j in range(i+3, min(i+7, len(seq))):
                    if seq[j].startswith("b"):
                        return True
        return False

# ---------------- GhostAI & Recorder (expanded) ----------------
class GhostAI:
    def __init__(self):
        self.patterns = {}  # situation->list of actions
        self.count = 0
    def decide(self, match: MatchInfo) -> str:
        # simple priority rules enhanced
        if match.p1_health < 0.25:
            return "defend"
        if match.distance_px < 120:
            return "cr.MK"
        if match.p1_super > 0.9:
            return "use_super"
        return "neutral"
    def record(self, situation, action):
        self.patterns.setdefault(situation, []).append(action)
        self.count += 1
    def save(self, path):
        try:
            with open(path, "w") as f:
                json.dump(self.patterns, f)
        except Exception as e:
            print("Ghost save failed:", e)
    def load(self, path):
        try:
            with open(path) as f:
                self.patterns = json.load(f)
        except Exception:
            pass

class Recorder:
    def __init__(self):
        self.records = []
    def record(self, info: MatchInfo, action):
        self.records.append({"info": info.__dict__, "action": action, "ts": time.time()})
    def save(self, path):
        try:
            with open(path, "w") as f:
                json.dump(self.records, f)
        except Exception as e:
            print("Recorder save failed:", e)

# ---------------- OCR calibration GUI ----------------
def ocr_calibration_gui(save_path=CONFIG_SAVE):
    if not HAS_TK:
        print("Tkinter not available; cannot run OCR calibration GUI.")
        return
    root = tk.Tk()
    root.withdraw()
    messagebox.showinfo("OCR Calibration", "You will be asked to click/select regions for OCR. Make sure the game window is visible.")
    # ask for regions: left char, right char, SA region (enter as 'x,y,w,h')
    left = simpledialog.askstring("Left portrait region", "Enter left portrait region as x,y,w,h (or leave blank to skip):")
    right = simpledialog.askstring("Right portrait region", "Enter right portrait region as x,y,w,h (or leave blank to skip):")
    sa = simpledialog.askstring("SA region", "Enter SA meter region as x,y,w,h (or leave blank to skip):")
    cfg = {}
    if left: cfg['left'] = left
    if right: cfg['right'] = right
    if sa: cfg['sa'] = sa
    try:
        with open(save_path, "w") as f:
            json.dump(cfg, f)
        messagebox.showinfo("Saved", f"Saved OCR regions to {save_path}")
    except Exception as e:
        messagebox.showerror("Error", str(e))
    root.destroy()

# ---------------- FFmpeg clip capture (640x480@60 by default) ----------------
def capture_clip(window_id: str, out_path: str, duration: int = FFMPEG_CLIP_DURATION):
    if not FFMPEG:
        print("ffmpeg not found; cannot capture clip.")
        return False
    # get window geometry
    try:
        r = subprocess.run(["xdotool","getwindowgeometry","--shell",window_id], capture_output=True, text=True, check=True)
        geom = {}
        for line in r.stdout.splitlines():
            if "=" in line:
                k,v = line.split("=",1); geom[k.strip()] = int(v.strip())
        left, top, w, h = geom.get("X",0), geom.get("Y",0), geom.get("WIDTH",CAPTURE_WIDTH), geom.get("HEIGHT",CAPTURE_HEIGHT)
    except Exception:
        left, top, w, h = 0, 0, CAPTURE_WIDTH, CAPTURE_HEIGHT
    # build ffmpeg command for x11grab (works on X11)
    cmd = [
        "ffmpeg", "-y", "-f", "x11grab",
        "-video_size", f"{w}x{h}",
        "-framerate", str(CAPTURE_FPS),
        "-i", f":0.0+{left},{top}",
        "-t", str(duration),
        "-vcodec", "libx264", "-preset", "veryfast", "-pix_fmt", "yuv420p",
        out_path
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=duration+10)
        if proc.returncode == 0:
            print("Captured clip to", out_path)
            return True
        else:
            print("ffmpeg failed:", proc.stderr)
            return False
    except Exception as e:
        print("ffmpeg capture exception:", e)
        return False

# ---------------- Monitor loop (integrates everything) ----------------
def monitor_loop(window_id: str, p1_ctrl, p2_ctrl):
    info = MatchInfo()
    ghost = GhostAI()
    recorder = Recorder()
    joy_reader = None
    if HAS_PYGAME:
        joy_reader = JoystickInputReader(0, axis_deadzone=0.25)
    seq_detector = JoySeqDetector()
    if joy_reader and joy_reader.j:
        def cb(ev): seq_detector.push(ev)
        joy_reader.callbacks.append(cb)
        joy_reader.start()
    print("\\n-- MATCH MONITOR STARTED -- (type 'help' then Enter for options)\\n")
    stop = {"v": False}
    def cmd_reader():
        while not stop["v"]:
            try:
                cmd = input()
            except Exception:
                cmd = ""
            cmd = cmd.strip().lower()
            if cmd == "help":
                print("Commands: help, stop, clip, saveghost, savecfg")
            elif cmd in ("quit","stop","exit"):
                stop["v"] = True
                break
            elif cmd == "clip":
                outp = str(Path.home()/("match_clip_"+str(int(time.time()))+".mp4"))
                capture_clip(window_id, outp, duration=FFMPEG_CLIP_DURATION)
            elif cmd == "saveghost":
                ghost.save(str(Path.home()/".ghost_patterns.json"))
                print("Ghost saved.")
            elif cmd == "savecfg":
                print("Saving calibration (if any).")
    tcmd = threading.Thread(target=cmd_reader, daemon=True)
    tcmd.start()

    last_p2_health = info.p2_health
    try:
        while not stop["v"]:
            # vision read (if available)
            if HAS_VISION:
                try:
                    r = subprocess.run(["xdotool","getwindowgeometry","--shell",window_id], capture_output=True, text=True, check=True)
                    geom = {}
                    for line in r.stdout.splitlines():
                        if "=" in line:
                            k,v = line.split("=",1); geom[k.strip()] = int(v.strip())
                    left, top, w, h = geom.get("X",0), geom.get("Y",0), geom.get("WIDTH",CAPTURE_WIDTH), geom.get("HEIGHT",CAPTURE_HEIGHT)
                    sct = mss.mss(); img = sct.grab({"left": left, "top": top, "width": w, "height": h}); arr = np.array(img)
                    if arr.shape[2] == 4: arr = arr[:,:,:3]
                    # health boxes
                    y = int(h*0.05); hh = int(h*0.03)
                    p1crop = arr[y:y+hh, int(w*0.05):int(w*0.35)]
                    p2crop = arr[y:y+hh, int(w*0.65):int(w*0.95)]
                    # quick brightness heuristic
                    def mean_v(c):
                        hsv = cv2.cvtColor(c, cv2.COLOR_BGR2HSV)
                        return float(hsv[:,:,2].mean())/255.0
                    info.p1_health = min(1.0, max(0.0, mean_v(p1crop)))
                    info.p2_health = min(1.0, max(0.0, mean_v(p2crop)))
                    # distance estimate via bright column heuristic
                    gray = cv2.cvtColor(arr, cv2.COLOR_BGR2GRAY)
                    th = cv2.threshold(gray, 200, 255, cv2.THRESH_BINARY)[1]
                    cols = th.sum(axis=0)
                    if cols.max() > 0:
                        lx = int(cols.argmax())
                        rx = int(cols[::-1].argmax())
                        info.distance_px = abs(rx - lx)
                except Exception as e:
                    # fallback simulation
                    info.p1_health = max(0.0, min(1.0, info.p1_health + (0.5 - __import__('random').random())*0.01))
                    info.p2_health = max(0.0, min(1.0, info.p2_health + (0.5 - __import__('random').random())*0.01))
                    info.distance_px = max(50, min(400, info.distance_px + int((__import__('random').random()-0.5)*8)))
            else:
                # simulate small fluctuations
                info.p1_health = max(0.0, min(1.0, info.p1_health + (0.5 - __import__('random').random())*0.01))
                info.p2_health = max(0.0, min(1.0, info.p2_health + (0.5 - __import__('random').random())*0.01))
                info.distance_px = max(50, min(400, info.distance_px + int((__import__('random').random()-0.5)*8)))

            # Ghost decision & recording example
            action = ghost.decide(info)
            info.last_action = action
            if action:
                recorder.record(info, action)

            # detect large drop for auto-clip (KO-like)
            if (last_p2_health - info.p2_health) > 0.20 and FFMPEG:
                # big drop detected -> capture short clip
                outp = str(Path.home()/("auto_clip_"+str(int(time.time()))+".mp4"))
                print("Large health drop detected — capturing clip to", outp)
                capture_clip(window_id, outp, duration=FFMPEG_CLIP_DURATION)
            last_p2_health = info.p2_health

            # print status
            print("\\n[MATCH] {} (You) vs {} (Opponent)".format(info.p1_name, info.p2_name))
            print(" [HEALTH] P1: {} {:3d}%  |  P2: {} {:3d}%".format(health_bar(info.p1_health,10), int(info.p1_health*100), health_bar(info.p2_health,10), int(info.p2_health*100)))
            print(" [SUPER]  P1: {} {:>5} |  P2: {} {:>5}".format(meter_bar(info.p1_super,10), "{:.0f}%".format(info.p1_super*100), meter_bar(info.p2_super,10), "{:.0f}%".format(info.p2_super*100)))
            print(" [DISTANCE] {}".format(distance_bucket(info.distance_px)))
            print(" [ACTION] Ghost decided: {}".format(info.last_action))
            print(" [RESULT] {}".format(info.last_result))

            # check joystick hadoken
            if seq_detector.detect_hadoken():
                print(" P1: ←↙↓ + HP  [Hadoken]")

            time.sleep(0.2)
    finally:
        if joy_reader:
            joy_reader.stop()
        print("-- monitor stopped --")

# ---------------- Helper UI functions ----------------
def health_bar(perc, length=10):
    blocks = int(round(perc*length))
    return "█"*blocks + "░"*(length-blocks)

def meter_bar(perc, length=10):
    blocks = int(round(perc*length))
    return "═"*blocks + "░"*(length-blocks)

def distance_bucket(px):
    if px < 100: return "Close ({}px)".format(px)
    if px < 220: return "Medium ({}px)".format(px)
    return "Far ({}px)".format(px)

# ---------------- Menus ----------------
def debug_menu():
    while True:
        print("\\n=== DEBUG MENU ===")
        print("1. Wait for window (boot-watch)")
        print("2. Calibrate gamepad (log axes/buttons)")
        print("3. Detect controllers & keyboard")
        print("4. Test window & send sample inputs")
        print("5. OCR calibration GUI (if tkinter)")
        print("6. Continue to Bot Menu")
        print("7. Exit")
        sel = input("Select: ").strip()
        if sel == "1":
            print("Waiting for window... (Ctrl+C to cancel)")
            try:
                while True:
                    wid = find_best_game_window()
                    if wid:
                        print("Found window:", wid, subprocess.run(["xdotool","getwindowname",wid], capture_output=True, text=True).stdout.strip())
                        break
                    time.sleep(0.5)
            except KeyboardInterrupt:
                print("Cancelled.")
        elif sel == "2":
            run_gamepad_calibration(10)
        elif sel == "3":
            pads = detect_gamepads(); print("Gamepads:", pads)
            if HAS_PYNPUT:
                print("Press a key now to test keyboard detection for 3 seconds...")
                print("Detected keyboard activity:" , detect_keyboard_activity_simple(3.0))
        elif sel == "4":
            wid = find_best_game_window()
            if not wid:
                print("No window found.")
                continue
            print("Window:", wid)
            for k in ["a","d","w","s"]:
                ok = activate_and_send(wid, k)
                print("Sent", k, ":", "OK" if ok else "FAIL")
        elif sel == "5":
            ocr_calibration_gui()
        elif sel == "6":
            return
        elif sel == "7":
            sys.exit(0)
        else:
            print("Invalid")

def bot_menu():
    while True:
        print("\\n=== 3RD STRIKE BOT ===")
        print("1. Mirror Mode (copy P1 inputs to P2)")
        print("2. Simple AI (hardcoded behavior)")
        print("3. Record Training Session (demo)")
        print("4. Play with Ghost AI (monitor)")
        print("5. Save Ghost Patterns")
        print("6. Load Ghost Patterns")
        print("7. Help")
        print("8. Exit")
        sel = input("Select option (1-8): ").strip()
        if sel == "1":
            print("Starting Mirror Mode (simple)")
            simple_mirror_mode()
        elif sel == "2":
            print("Simple AI: mirror demo")
            simple_mirror_mode()
        elif sel == "3":
            print("Record training - demo (not full)")
        elif sel == "4":
            wid = find_best_game_window()
            if not wid:
                print("No game window found. Use Debug Menu to confirm.")
                continue
            p1 = detect_controllers_interactive("P1"); p2 = detect_controllers_interactive("P2")
            print("Waiting for character select... press Enter when ready")
            input()
            monitor_loop(wid, p1, p2)
        elif sel == "5":
            g = GhostAI(); g.save(str(Path.home()/".ghost_patterns.json")); print("Saved ghost patterns (empty).")
        elif sel == "6":
            g = GhostAI(); g.load(str(Path.home()/".ghost_patterns.json")); print("Loaded ghost patterns (if existed).")
        elif sel == "7":
            print_help()
        elif sel == "8":
            break
        else:
            print("Invalid")

# detect functions used by menus
def detect_gamepads():
    pads = []
    if not HAS_PYGAME:
        return pads
    try:
        import pygame
        pygame.init(); pygame.joystick.init()
        for i in range(pygame.joystick.get_count()):
            j = pygame.joystick.Joystick(i); j.init()
            pads.append({"id": i, "name": j.get_name(), "axes": j.get_numaxes(), "buttons": j.get_numbuttons()})
    except Exception as e:
        print("gamepad detect failed:", e)
    return pads

def detect_keyboard_activity_simple(timeout=3.0):
    if not HAS_PYNPUT: return False
    hit = {"v": False}
    def on_press(key): hit["v"] = True
    l = kb.Listener(on_press=on_press); l.start()
    t0 = time.time()
    while time.time() - t0 < timeout and not hit["v"]:
        time.sleep(0.05)
    l.stop()
    return hit["v"]

def detect_controllers_interactive(role="P1"):
    pads = detect_gamepads()
    if pads:
        print("Detected gamepads:")
        for i,p in enumerate(pads,1):
            print(" ", i, p["name"])
        sel = input("Select (1-{}) or Enter for 1: ".format(len(pads))).strip()
        try: idx = int(sel)-1 if sel else 0
        except: idx = 0
        return {"type":"gamepad", "source": pads[idx]}
    print("No gamepads: listening for keyboard activity...")
    kbact = detect_keyboard_activity_simple(3.0)
    if kbact: return {"type":"keyboard", "source":"keyboard"}
    if Path(FIGHTCADE_LOG_PATH).exists(): return {"type":"log", "source": FIGHTCADE_LOG_PATH}
    return {"type":"manual", "source":"manual"}

def ocr_calibration_gui():
    try:
        from tkinter import Tk, simpledialog, messagebox
    except Exception:
        print("tkinter not available")
        return
    root = Tk(); root.withdraw()
    messagebox.showinfo("OCR Calibration", "Make sure the game window is visible. Enter regions as x,y,w,h.")
    left = simpledialog.askstring("Left portrait", "Left portrait region (x,y,w,h) or blank:")
    right = simpledialog.askstring("Right portrait", "Right portrait region (x,y,w,h) or blank:")
    sa = simpledialog.askstring("SA region", "SA region (x,y,w,h) or blank:")
    cfg = {}
    if left: cfg["left"] = left
    if right: cfg["right"] = right
    if sa: cfg["sa"] = sa
    try:
        with open(str(CONFIG_SAVE), "w") as f:
            json.dump(cfg, f)
        messagebox.showinfo("Saved", "Saved OCR config to {}".format(CONFIG_SAVE))
    except Exception as e:
        messagebox.showerror("Error", str(e))
    root.destroy()

def print_help():
    print("\\nHelp:")
    print("- Type 'help' while monitoring for commands: clip, saveghost, savecfg, stop")
    print("- Use Debug Menu -> Calibrate gamepad to create calibration log for tuning.")
    print("- ffmpeg clip capture uses X11 x11grab; on Wayland you'll need wf-recorder or PipeWire tools.")

def main():
    print("3rd Strike Advanced - Tuned Build")
    time.sleep(0.2)
    while True:
        print("\\nMAIN MENU:")
        print("1. Debug Menu (window test / calibrate / detect controls)")
        print("2. Bot Menu (Mirror, AI, Record, Ghost)")
        print("3. Exit")
        sel = input("Select: ").strip()
        if sel == "1":
            debug_menu()
        elif sel == "2":
            bot_menu()
        elif sel == "3":
            print("Bye."); break
        else:
            print("Invalid")

if __name__ == '__main__':
    main()
