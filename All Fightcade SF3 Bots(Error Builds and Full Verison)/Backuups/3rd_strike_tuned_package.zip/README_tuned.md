3rd Strike Advanced - Tuned Package

Files:
- 3rd_Strike_Advanced_tuned.py : main script (CLI-first)

Configured for your environment:
- Fightcade input log path (fallback): /home/bemo9000/.var/app/com.fightcade.Fightcade/data/config/fcadefbneo/presets/cps.ini
- Capture settings (ffmpeg): 640x480 @ 60 fps

Dependencies (install for full functionality):
sudo apt install xdotool tesseract-ocr ffmpeg python3-tk
pip install pygame pynput mss opencv-python numpy pillow pytesseract

How to run:
python3 3rd_Strike_Advanced_tuned.py

Use the Debug Menu first to calibrate your Mayflash F300 and confirm window detection, then use Bot Menu -> Play with Ghost AI.