Fixed version of fighting_game_ai.py for Fightcade.

Run with:
  python3 fighting_game_ai_fixed.py
