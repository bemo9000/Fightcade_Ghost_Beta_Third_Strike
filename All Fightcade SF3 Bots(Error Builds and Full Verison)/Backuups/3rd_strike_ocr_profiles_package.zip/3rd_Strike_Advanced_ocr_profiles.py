#!/usr/bin/env python3
\"\"\"3rd_Strike_Advanced_ocr_profiles.py

Adds:
- OCR-based character / Super Art detection using pytesseract (if available) and Tesseract binary.
- Profile system for control mappings and mirror settings (saved in ~/.3rd_strike_bot_profiles.json).
- Improved rematch remembering and SA changes detection via OCR snapshot.
- Robust fallbacks if pytesseract/Tesseract are missing: interactive prompts remain.
- Exports package as ZIP when run with --export-zip.

Requirements (optional features):
- pytesseract + pillow + opencv + mss for OCR: `pip install pytesseract pillow opencv-python mss`
- tesseract-ocr binary installed on system (e.g., `sudo apt install tesseract-ocr`)
- pynput for input listening
- xdotool on Linux for sending keys

\"\"\"

import argparse
import json
import logging
import os
import subprocess
import sys
import threading
import time
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

# Optional libs
try:
    from pynput import keyboard as kb
    HAS_PYNPUT = True
except Exception:
    HAS_PYNPUT = False

try:
    import cv2, numpy as np, mss
    HAS_CV2 = True
    HAS_MSS = True
except Exception:
    HAS_CV2 = False
    HAS_MSS = False

try:
    import pytesseract
    from PIL import Image
    HAS_PYTESSERACT = True
except Exception:
    HAS_PYTESSERACT = False

CONFIG_PATH = Path.home() / \".3rd_strike_bot_config.json\"
PROFILES_PATH = Path.home() / \".3rd_strike_bot_profiles.json\"

DEFAULT_WINDOW_NAME = \"Fightcade\"

# ------------------------ Persistence utilities ------------------------
def load_json(p: Path) -> dict:
    if p.exists():
        try:
            return json.loads(p.read_text())
        except Exception:
            return {}
    return {}

def save_json(p: Path, data: dict):
    try:
        p.write_text(json.dumps(data, indent=2))
    except Exception as e:
        logging.exception(\"Failed to write %s: %s\", p, e)

# ------------------------ Simple GameState ------------------------
@dataclass
class GameState:
    timestamp: float
    distance: float = 320.0
    p1_health: float = 1.0
    p2_health: float = 1.0

# ------------------------ Window utilities ------------------------
def find_window(window_name_fuzzy: str = DEFAULT_WINDOW_NAME) -> Optional[str]:
    try:
        r = subprocess.run([\"xdotool\", \"search\", \"--name\", window_name_fuzzy], capture_output=True, text=True, check=True)
        ids = [l.strip() for l in r.stdout.splitlines() if l.strip()]
        return ids[0] if ids else None
    except Exception:
        return None

def wait_for_window(window_name_fuzzy: str = DEFAULT_WINDOW_NAME, timeout: Optional[float] = None):
    logging.info(f\"Waiting for window matching '{window_name_fuzzy}'...\")
    start = time.time()
    while True:
        w = find_window(window_name_fuzzy)
        if w:
            logging.info(f\"Found window: {w}\")
            return w
        if timeout and (time.time() - start) > timeout:
            logging.warning(\"Timeout waiting for window.\")
            return None
        time.sleep(0.5)

# ------------------------ Executor ------------------------
class LinuxInputExecutor:
    def __init__(self, window_name_fuzzy: str = DEFAULT_WINDOW_NAME, profile: Optional[dict] = None):
        self.window_name_fuzzy = window_name_fuzzy
        self.window_id = find_window(window_name_fuzzy)
        default_map = {'up': 'w', 'down':'s','left':'a','right':'d','lp':'y','mp':'u','hp':'i','lk':'h','mk':'j','hk':'k'}
        self.key_map = (profile or {}).get('key_map', default_map)

    def refresh_window(self):
        self.window_id = find_window(self.window_name_fuzzy)

    def send_key(self, key: str):
        if not self.window_id:
            logging.debug(\"No window id; cannot send key\")
            return False
        mapped = self.key_map.get(key, key)
        try:
            subprocess.run([\"xdotool\", \"key\", \"--window\", self.window_id, mapped], check=True, capture_output=True)
            logging.debug(f\"Sent key '{key}' -> '{mapped}' to window {self.window_id}\")
            return True
        except Exception as e:
            logging.exception(\"Failed to send key: %s\", e)
            return False

# ------------------------ Profiles ------------------------
def load_profiles() -> dict:
    return load_json(PROFILES_PATH)

def save_profiles(profiles: dict):
    save_json(PROFILES_PATH, profiles)

def ensure_default_profile():
    profiles = load_profiles()
    if 'default' not in profiles:
        profiles['default'] = {
            'key_map': {'up':'w','down':'s','left':'a','right':'d','lp':'y','mp':'u','hp':'i','lk':'h','mk':'j','hk':'k'},
            'mirror_settings': {'mode':'exact','delay':0.05,'max_random':0.2,'mistake_prob':0.02}
        }
        save_profiles(profiles)

# ------------------------ OCR helpers ------------------------
def is_tesseract_installed() -> bool:
    try:
        subprocess.run(['tesseract','--version'], capture_output=True, check=True)
        return True
    except Exception:
        return False

def ocr_read_text_from_screenshot(region: Tuple[int,int,int,int]) -> str:
    # region: left,top,width,height on primary monitor capture
    if not (HAS_MSS and HAS_CV2 and HAS_PYTESSERACT and is_tesseract_installed()):
        raise RuntimeError('OCR prerequisites missing')
    sct = mss.mss()
    img = sct.grab({'left': region[0], 'top': region[1], 'width': region[2], 'height': region[3]})
    arr = np.array(img)
    if arr.shape[2] == 4:
        arr = arr[:,:,:3]
    pil = Image.fromarray(arr)
    text = pytesseract.image_to_string(pil)
    return text.strip()

def detect_character_and_sa_via_ocr(executor: LinuxInputExecutor) -> Tuple[Optional[str], Optional[str]]:
    # Attempt to find window geometry via xdotool and capture select-screen regions.
    # This is heuristic: different clients need tuning; we provide reasonable guesses.
    if not (HAS_MSS and HAS_CV2 and HAS_PYTESSERACT and is_tesseract_installed()):
        logging.info('OCR not available; skipping OCR detection.')
        return None, None
    executor.refresh_window()
    if not executor.window_id:
        logging.warning('No window to snapshot for OCR.')
        return None, None
    # Try to get window geometry via xdotool getwindowgeometry --shell
    try:
        r = subprocess.run(['xdotool','getwindowgeometry','--shell', executor.window_id], capture_output=True, text=True, check=True)
        geom = {}
        for line in r.stdout.splitlines():
            if '=' in line:
                k,v = line.split('=',1)
                geom[k.strip()] = int(v.strip())
        left = geom.get('X',0); top = geom.get('Y',0); w = geom.get('WIDTH',640); h = geom.get('HEIGHT',480)
    except Exception:
        # fallback to full monitor
        mon = mss.mss().monitors[0]
        left, top, w, h = mon['left'], mon['top'], mon['width'], mon['height']
    # heuristics: character names often appear near top/center of select screen; SA shown under portrait
    # We'll sample a few candidate boxes and run OCR
    candidates = [
        (left + int(w*0.10), top + int(h*0.10), int(w*0.15), int(h*0.10)), # left portrait text region
        (left + int(w*0.75), top + int(h*0.10), int(w*0.15), int(h*0.10)), # right portrait text region
        (left + int(w*0.45), top + int(h*0.75), int(w*0.10), int(h*0.08)), # SA region guess
    ]
    texts = []
    for reg in candidates:
        try:
            t = ocr_read_text_from_screenshot(reg)
            logging.debug(f\"OCR region {reg} -> '{t}'\")
            texts.append(t)
        except Exception as e:
            logging.debug('OCR read failed for region: %s', e)
            texts.append('')
    # naive parsing: look for known character names or strings like SA1/SA2/SA3
    all_text = ' '.join(texts).lower()
    logging.info(f\"OCR combined text: {all_text}\")
    # common characters list (partial); extendable
    chars = ['alex','ryu','ken','chun-li','chun li','chunli','elena','remy','gouki','hugo','makoto','dudley','necros']
    found_char = None
    for c in chars:
        if c in all_text:
            found_char = c.replace('-', '').replace(' ', '')  # normalize
            break
    sa = None
    for token in ['sa1','sa2','sa3','super art 1','super art 2','super art 3']:
        if token in all_text:
            if '1' in token:
                sa = 'SA1'
            elif '2' in token:
                sa = 'SA2'
            elif '3' in token:
                sa = 'SA3'
            break
    return found_char, sa

# ------------------------ Control detection ------------------------
def detect_controls(timeout: float = 4.0) -> Dict[str,str]:
    logging.info(\"Detecting controls: press some keys for P1 and P2. Listening for %s seconds...\", timeout)
    detected = set()
    results = {'p1':'unknown','p2':'unknown'}
    if not HAS_PYNPUT:
        logging.warning('pynput missing; falling back to defaults.')
        return {'p1':'arrows','p2':'wasd'}
    def on_press(key):
        try:
            k = key.char.lower()
        except Exception:
            k = str(key).split('.')[-1].lower()
        detected.add(k)
    listener = kb.Listener(on_press=on_press)
    listener.start()
    time.sleep(timeout)
    listener.stop()
    arrow_keys = {'up','down','left','right','up_arrow','down_arrow','left_arrow','right_arrow'}
    wasd = {'w','a','s','d'}
    p2_buttons = {'y','u','i','h','j','k'}
    if detected & arrow_keys:
        results['p1'] = 'arrows'
    if detected & wasd or detected & p2_buttons:
        results['p2'] = 'wasd'
    if results['p1']=='unknown' and results['p2']!='unknown':
        results['p1'] = 'arrows'
    if results['p2']=='unknown' and results['p1']!='unknown':
        results['p2'] = 'wasd'
    logging.info('Detected keys: %s', detected)
    logging.info('Control detection result: %s', results)
    return results

# ------------------------ Simple mirror using mapping profile ------------------------
class SimpleMirror:
    def __init__(self, executor: LinuxInputExecutor, profiles: dict):
        self.executor = executor
        self.listener = None
        self.running = False
        self.profiles = profiles
        self.profile = profiles.get('default', {})
        self.map_table = self.profile.get('mirror_map', {'left':'a','right':'d','up':'w','down':'s','y':'y','u':'u','i':'i','h':'h','j':'j','k':'k'})

    def _normalize_key(self, key):
        try:
            return key.char.lower()
        except Exception:
            return str(key).split('.')[-1].lower()

    def _on_press(self, key):
        k = self._normalize_key(key)
        mapped = self.map_table.get(k)
        if mapped:
            self.executor.send_key(mapped)
            logging.debug(f\"SimpleMirror: mapped {k} -> {mapped}\")

    def start(self):
        if not HAS_PYNPUT:
            logging.error('pynput required for SimpleMirror')
            return
        self.listener = kb.Listener(on_press=self._on_press)
        self.listener.start()
        self.running = True
        logging.info('SimpleMirror started')

    def stop(self):
        if self.listener:
            self.listener.stop()
        self.running = False
        logging.info('SimpleMirror stopped')

# ------------------------ Main interactive flow ------------------------
def main_menu(window_name=DEFAULT_WINDOW_NAME):
    ensure_default_profile()
    profiles = load_profiles()
    executor = LinuxInputExecutor(window_name, profile=profiles.get('default'))
    print('\\n=== 3RD STRIKE BOT (OCR + Profiles) ===')
    while True:
        print('\\n1. Boot-watch and auto-detect') 
        print('2. Detect controls now') 
        print('3. OCR detect character + SA (if available)') 
        print('4. Start Simple mirror (P1->P2)') 
        print('5. Edit profiles') 
        print('6. Help') 
        print('7. Export ZIP') 
        print('8. Exit') 
        sel = input('Select (1-8): ').strip()
        if sel == '1':
            print('Boot-watch: waiting for game...') 
            w = wait_for_window(window_name)
            if not w:
                print('Window not found.')
                continue
            controls = detect_controls(timeout=4.0)
            print(f\"Detected controls: {controls}\") 
            # try OCR detection
            found_char, sa = detect_character_and_sa_via_ocr(executor)
            if found_char:
                print(f\"OCR detected character: {found_char}, SA: {sa}\") 
                cfg = load_json(CONFIG_PATH)
                cfg.setdefault('last_picks', {}) 
                cfg['last_picks']['p1'] = found_char 
                if sa: cfg['last_picks']['sa_p1'] = sa
                save_json(CONFIG_PATH, cfg)
            else:
                # fallback interactive
                p1 = input(\"Who did YOU pick? (alex/ryu default 'alex'): \").strip() or 'alex'
                sa = input(\"Which SA? (SA1/SA2/SA3) default SA1: \").strip() or 'SA1'
                cfg = load_json(CONFIG_PATH)
                cfg.setdefault('last_picks', {}) 
                cfg['last_picks']['p1'] = p1 
                cfg['last_picks']['sa_p1'] = sa
                save_json(CONFIG_PATH, cfg)
                print(f\"Remembering {p1} ({sa})\")
        elif sel == '2':
            controls = detect_controls()
            print(f\"Controls: {controls}\")
        elif sel == '3':
            found_char, sa = detect_character_and_sa_via_ocr(executor)
            if found_char:
                print(f\"Detected via OCR: {found_char} ({sa})\")
            else:
                print('OCR detection not available or failed.')
        elif sel == '4':
            sm = SimpleMirror(executor, profiles)
            try:
                sm.start()
                print('SimpleMirror running. Ctrl+C to stop.')
                while True:
                    time.sleep(0.5)
            except KeyboardInterrupt:
                sm.stop()
                continue
        elif sel == '5':
            print('Profiles:') 
            for name, p in profiles.items():
                print(f\"- {name}: keys={list(p.get('key_map',{}).keys())} mirror={p.get('mirror_settings')}\")
            choice = input('Create/edit profile name (or blank to cancel): ').strip()
            if choice:
                kmap = profiles.get(choice, {}).get('key_map', {})
                if not kmap:
                    kmap = {'up':'w','down':'s','left':'a','right':'d','lp':'y','mp':'u','hp':'i','lk':'h','mk':'j','hk':'k'}
                print('Current key map (press enter to keep):') 
                for k,v in kmap.items():
                    nv = input(f\"{k} -> [{v}]: \").strip()
                    if nv:
                        kmap[k] = nv
                msettings = profiles.get(choice, {}).get('mirror_settings', {'mode':'exact','delay':0.05,'max_random':0.2,'mistake_prob':0.02})
                nm = input(f\"Mirror mode [{msettings['mode']}]: \").strip() or msettings['mode']
                try:
                    nd = float(input(f\"Delay seconds [{msettings['delay']}]: \").strip() or msettings['delay'])
                except:
                    nd = msettings['delay']
                try:
                    nr = float(input(f\"Max random [{msettings['max_random']}]: \").strip() or msettings['max_random'])
                except:
                    nr = msettings['max_random']
                try:
                    npv = float(input(f\"Mistake prob [{msettings['mistake_prob']}]: \").strip() or msettings['mistake_prob'])
                except:
                    npv = msettings['mistake_prob']
                profiles[choice] = {'key_map':kmap, 'mirror_settings': {'mode':nm,'delay':nd,'max_random':nr,'mistake_prob':npv}}
                save_profiles(profiles)
                print(f\"Profile '{choice}' saved.\")
        elif sel == '6':
            print('Help: OCR requires pytesseract and Tesseract binary. Profiles stored at', PROFILES_PATH)
        elif sel == '7':
            # create zip of this script and README if exists
            here = Path('.').resolve()
            zipname = '3rd_strike_ocr_profiles_package.zip'
            with zipfile.ZipFile(zipname, 'w', compression=zipfile.ZIP_DEFLATED) as z:
                z.write(__file__, arcname=Path(__file__).name)
            print('Created', zipname)
        elif sel == '8':
            print('Exiting.')
            break
        else:
            print('Invalid selection.')

def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--menu', action='store_true')
    parser.add_argument('--boot-watch', action='store_true')
    parser.add_argument('--window-name', type=str, default=DEFAULT_WINDOW_NAME)
    parser.add_argument('--export-zip', action='store_true')
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s: %(message)s')
    ensure_default_profile()
    if args.export_zip:
        zipname = '3rd_strike_ocr_profiles_package.zip'
        with zipfile.ZipFile(zipname, 'w', compression=zipfile.ZIP_DEFLATED) as z:
            z.write(__file__, arcname=Path(__file__).name)
        print('Created', zipname)
        return
    if args.menu:
        main_menu(window_name=args.window_name)
        return
    if args.boot_watch:
        w = wait_for_window(args.window_name)
        if not w:
            print('Window not found.')
            return
        controls = detect_controls(timeout=4.0)
        print('Controls:', controls)
        executor = LinuxInputExecutor(args.window_name)
        found_char, sa = detect_character_and_sa_via_ocr(executor)
        if found_char:
            print(f\"Detected: {found_char} ({sa})\")
        else:
            print('OCR detection failed or not available.')
        return
    main_menu(window_name=args.window_name)

if __name__ == '__main__':
    main()
