Fightcade SFIII:3rd Strike AI Bot

Controls mapped for P2:
W=Up, S=Down, A=Left, D=Right
Y=Weak Punch, U=Medium Punch, I=Strong Punch
H=Weak Kick, J=Medium Kick, K=Heavy Kick
6=Coin/Select, 2=Start

Run with:
  python3 fighting_game_ai_final.py

Requires xdotool installed.
